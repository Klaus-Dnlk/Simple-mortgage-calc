import { createAction } from '@reduxjs/toolkit';

const changeFilter = createAction('banks/filter');
export default changeFilter;
