export const getLoading = (state) => state.banks.loading;

export const getFilter = (state) => state.banks.filter;

export const getAllBanks = (state) => state.banks.items;
