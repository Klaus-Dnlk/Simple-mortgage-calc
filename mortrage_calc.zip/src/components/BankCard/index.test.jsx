// import React from 'react';
// import { axe } from 'jest-axe';
// import { render, screen, fireEvent } from '@testing-library/react';
// import '@testing-library/jest-dom/extend-expect';
// import BankCard from './index';

// describe('BankCard Component', () => {
//   const bankProps = {
//     name: "Test Bank",
//     interestRate: 5,
//     maxLoan: 100000,
//     minDownPayment: 20,
//     loanTerm: 10
//   };

//   it('renders correctly with given props', () => {
//     render(<BankCard {...bankProps} />);
    
//     expect(screen.getByText(bankProps.name)).toBeInTheDocument();
//     expect(screen.getByText(`${bankProps.interestRate}%`)).toBeInTheDocument();
//     expect(screen.getByText(`$${bankProps.maxLoan}`)).toBeInTheDocument();
//     expect(screen.getByText(`${bankProps.minDownPayment}%`)).toBeInTheDocument();
//     expect(screen.getByText(`${bankProps.loanTerm} years`)).toBeInTheDocument();
//   });

//   it('displays the correct interest rate', () => {
//     render(<BankCard {...bankProps} />);
//     expect(screen.getByTestId('interestRate')).toHaveTextContent(`${bankProps.interestRate}%`);
//   });

//   it('handles button click', () => {
//     const mockOnClick = jest.fn();
//     render(<BankCard {...bankProps} onClick={mockOnClick} />);
//     fireEvent.click(screen.getByText(/apply now/i));
//     expect(mockOnClick).toHaveBeenCalledTimes(1);
//   });

//   it('displays a special badge for low interest rates', () => {
//     const lowInterestProps = {...bankProps, interestRate: 4.5};
//     render(<BankCard {...lowInterestProps} />);
//     expect(screen.getByText('Low Interest!')).toBeInTheDocument();
//   });

//   it('updates correctly when props change', () => {
//     const { rerender } = render(<BankCard {...bankProps} />);
//     const newProps = { ...bankProps, interestRate: 6, loanTerm: 15 };
//     rerender(<BankCard {...newProps} />);
    
//     expect(screen.getByTestId('interestRate')).toHaveTextContent('6%');
//     expect(screen.getByText('15 years')).toBeInTheDocument();
//   });

//   it('displays an error message when there is an error prop', () => {
//     const errorProps = { ...bankProps, error: 'Failed to load data' };
//     render(<BankCard {...errorProps} />);
    
//     expect(screen.getByText(/failed to load data/i)).toBeInTheDocument();
//   });


//   // Accessibility
//   it('is accessible according to ARIA roles and properties', async () => {
//     const { container } = render(<BankCard {...bankProps} />);
//     const results = await axe(container);
    
//     expect(results).toHaveNoViolations();
//   });

//   //Snapshots
//   it('matches snapshot', () => {
//     const {tree} = render(<BankCard {...bankProps} />);
//     expect(tree.asFragment()).toMatchSnapshot();
//   });

//   it('handles extreme values gracefully', () => {
//     const extremeProps = {
//       ...bankProps,
//       interestRate: 0,
//       maxLoan: 10000000,
//     };
//     render(<BankCard {...extremeProps} />);
    
//     expect(screen.getByTestId('interestRate')).toHaveTextContent('0%');
//     expect(screen.getByText('$10000000')).toBeInTheDocument();
//   });



// });
