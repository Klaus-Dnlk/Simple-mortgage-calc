import React from 'react';
import { render, fireEvent, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Calc from './index';
import { banksOperations, banksSelectors } from '../../redux/banks';
import { Provider } from 'react-redux';
import * as reduxHooks from 'react-redux';

// Mocks
const mockBanks = [
  { id: '1', BankName: 'Bank A', MaximumLoan: '500000', MinimumDownPayment: '50000', LoanTerm: '20', InterestRate: '5' },
  
];
jest.mock('../../redux/banks');
reduxHooks.useSelector.mockImplementation((selector) => selector({ banks: { isLoading: false, list: mockBanks } }));
banksOperations.fetchBanks = jest.fn();

// Custom Matchers
expect.extend({
  toBeValidInterestRate(received) {
    const pass = received >= 0 && received <= 100;
    if (pass) {
      return {
        message: () => `expected ${received} to be a valid interest rate`,
        pass: true,
      };
    } else {
      return {
        message: () => `expected ${received} to be a valid interest rate`,
        pass: false,
      };
    }
  },
  // ...other custom matchers...
});

describe('Calc Component Tests', () => {
  beforeEach(() => {
    // Setup
    render(<Provider store={mockStore}><Calc /></Provider>);
  });

  afterEach(() => {
    // Teardown
    jest.clearAllMocks();
  });

  // UI Component Tests
  test('renders the bank select input', () => {
    expect(screen.getByLabelText(/Bank name/i)).toBeVisible();
  });

  test('renders the initial loan input', () => {
    expect(screen.getByLabelText(/Initial Loan/i)).toBeVisible();
  });

  test('renders the down payment input', () => {
    expect(screen.getByLabelText(/Down Payment/i)).toBeVisible();
  });

  test('renders the loan term input', () => {
    expect(screen.getByLabelText(/Loan Term/i)).toBeVisible();
  });

  test('renders the APR input', () => {
    expect(screen.getByLabelText(/APR/i)).toBeVisible();
  });

  test('calculate button is present', () => {
    expect(screen.getByText(/Calculate/i)).toBeVisible();
  });

  test('reset icon button clears the form', () => {
    const resetButton = screen.getByTestId('reset');
    userEvent.click(resetButton);
    expect(screen.getByLabelText(/Initial Loan/i)).toHaveValue('');
  });

  // Business Logic Tests
  test('calculates the monthly payment correctly', () => {
    fireEvent.change(screen.getByLabelText(/Initial Loan/i), { target: { value: '100000' } });
    fireEvent.change(screen.getByLabelText(/APR/i), { target: { value: '5' } });
    fireEvent.change(screen.getByLabelText(/Loan Term/i), { target: { value: '30' } });
    fireEvent.click(screen.getByText(/Calculate/i));
    expect(screen.getByTestId('monthly-payment')).toHaveTextContent('Your monthly mortgage payment $536.82');
  });

  test('displays an error for invalid APR', () => {
    fireEvent.change(screen.getByLabelText(/APR/i), { target: { value: '105' } });
    fireEvent.click(screen.getByText(/Calculate/i));
    expect(screen.getByTestId('calc-error')).toHaveTextContent('Invalid interest rate');
  });

  test('shows a warning for high APR', () => {
    fireEvent.change(screen.getByLabelText(/APR/i), { target: { value: '16' } });
    fireEvent.click(screen.getByText(/Calculate/i));
    expect(screen.getByTestId('interest-rate-warning')).toHaveTextContent('Consider negotiating for a better rate');
  });

  test('resets error after valid input', () => {
    fireEvent.change(screen.getByLabelText(/APR/i), { target: { value: '105' } });
    fireEvent.click(screen.getByText(/Calculate/i));
    fireEvent.change(screen.getByLabelText(/APR/i), { target: { value: '5' } });
    fireEvent.click(screen.getByText(/Calculate/i));
    expect(screen.getByTestId('calc-error')).toBeEmptyDOMElement();
  });

  test('fills form fields with selected bank information', async () => {
    fireEvent.mouseDown(screen.getByLabelText(/Bank name/i));
    await screen.findByText('Bank A');
    fireEvent.click(screen.getByText('Bank A'));
    expect(screen.getByLabelText(/Initial Loan/i)).toHaveValue(mockBanks[0].MaximumLoan);
  });

});
