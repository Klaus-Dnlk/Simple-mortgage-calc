This is a draft version of the Mortgage calculator (draft, because some functions are not finished)

You can visit BANKS page to see banks and their term and conditions on credit service.

Bank page:
-- You can create a new Bank Card with mortgage credentials.
-- You can delete bank item from the list of you banks.

Calculator: You can use mortgage calculator by entering credentials by yourselfe of to choose the bank from select drop-down list.

I used mockapi server service for the testing of the application.
You can GET bank information, you can POST new items or DELETE them.
